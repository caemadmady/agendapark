/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useContext, useEffect, useState } from "react";
import { apiFetch, getToken, setToken as persistToken } from "../lib/api.js";
import { mapRole } from "./auth.utils.js";

const AuthContext = createContext(null);

// ----------------------------------------------------
function decodeToken(token) {
  try {
    const base64 = token
      .split(".")[1]
      .replace(/-/g, "+")
      .replace(/_/g, "/");

    return JSON.parse(atob(base64));
  } catch (e) {
    console.error("Error al decodificar token:", e);
    return null;
  }
}

// ----------------------------------------------------
async function fetchFullUserData(username) {
  try {
    return await apiFetch(`/usuarios/${username}`);
  } catch (e) {
    console.error("Error trayendo datos completos del usuario:", e);
    return null;
  }
}

// ----------------------------------------------------
function AuthProvider({ children }) {
  const [me, setMe] = useState(null);
  const [loadingMe, setLoadingMe] = useState(true);

  // ----------------------------------------------------
  useEffect(() => {
    const token = getToken();

    if (!token) {
      setLoadingMe(false);
      return;
    }

    const payload = decodeToken(token);
    if (!payload) {
      setLoadingMe(false);
      return;
    }

    persistToken(token);

    const baseUser = {
      username: payload.sub,
      role: mapRole(payload.role),
      name: payload.name || "",
      lastname: payload.lastname || "",
      lineaId: null,
    };

    fetchFullUserData(payload.sub).then((full) => {
      if (full) {
        setMe({
          ...baseUser,
          name: full.name ?? baseUser.name,
          lastname: full.lastname ?? baseUser.lastname,
          lineaId: full.line || full.linea || full.lineId || null,
        });
      } else {
        setMe(baseUser);
      }

      setLoadingMe(false);
    });
  }, []);

  // ----------------------------------------------------
  const login = async ({ username, password }) => {
    const resp = await apiFetch("/login", {
      method: "POST",
      body: { username, password },
    });

    const token = resp?.token;
    if (!token) throw new Error("Login inválido");

    persistToken(token);

    const payload = decodeToken(token);

    let user = {
      username: payload.sub,
      role: mapRole(payload.role),
      name: payload.name || "",
      lastname: payload.lastname || "",
      lineaId: null,
    };

    const fullData = await fetchFullUserData(payload.sub);

    if (fullData) {
      user = {
        ...user,
        name: fullData.name ?? user.name,
        lastname: fullData.lastname ?? user.lastname,
        lineaId: fullData.line || fullData.linea || fullData.lineId || null,
      };
    }

    setMe(user);
    return user;
  };

  const logout = () => {
    persistToken(null);
    setMe(null);
  };

  return (
    <AuthContext.Provider value={{ me, loadingMe, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export default AuthProvider;

export const useAuth = () => useContext(AuthContext);
