// src/auth/auth.utils.js

// Normaliza el rol
export const mapRole = (raw) => {
  if (!raw) return null;

  const x = String(raw)
    .toUpperCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");

  if (["ADMIN", "SUPERADMIN"].includes(x)) return "ADMIN";
  if (["SECURITY"].includes(x)) return "SECURITY";
  if (["EXPERTO", "EXPERT"].includes(x)) return "EXPERTO";
  if (["TALENTO", "TALENT"].includes(x)) return "TALENTO";
  return x;
};

// Normaliza la línea
// Solo funciona si el backend devuelve: serviceLine: { id: "TIC" }
export const mapLine = (dto = {}) => {
  return dto?.serviceLine?.id || dto?.line || dto?.lineId || null;
};
