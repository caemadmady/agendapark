import React from 'react';
import '../styles/AdminStatistics.css';

const StatItem = ({ label, value, color }) => {
  return (
    <div className="stat-item-card">
      <p className={`stat-value color-${color}`}>{value}</p>
      <p className="stat-label">{label}</p>
    </div>
  );
};

export default StatItem;