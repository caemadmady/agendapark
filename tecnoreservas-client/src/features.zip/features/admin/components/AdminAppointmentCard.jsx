import React from 'react';
import { FaCalendarAlt, FaClock, FaTag, FaTools, FaStickyNote } from 'react-icons/fa';
import '../styles/AdminAppointmentCard.css';

const AdminAppointmentCard = ({ appointment, onConfirm, onCancel }) => {
  const { talentName, expertName, date, time, duration, line, equipment, notes, status } = appointment;

  const isPending = status === 'Programada';
  const isConfirmed = status === 'Confirmada';
  const isCancelled = status === 'Cancelada';
  const isCompleted = status === 'Completada';

  return (
    <div className={`admin-appointment-card status-border-${status.toLowerCase()}`}>
      <div className="card-main-info">
        <div className="card-details">
          <h4 className="talent-name">{talentName}</h4>
          <p className="expert-name">con {expertName}</p>
          <div className="time-info">
            <span><FaCalendarAlt /> {date}</span>
            <span><FaClock /> {time} ({duration})</span>
            <span><FaTag /> {line}</span>
          </div>
          <div className="extra-info">
            <p><FaTools /> <strong>Equipos:</strong></p>
            <div className="equipment-tags">
              {equipment.map((item, index) => (
                <span key={index} className="equipment-tag">
                  {item.name} <em>({item.details})</em>
                </span>
              ))}
            </div>
          </div>
          <div className="extra-info">
            <p><FaStickyNote /> <strong>Notas:</strong> {notes}</p>
          </div>
        </div>

        <div className="card-actions">
          {/* Lógica condicional para mostrar botones/badges */}
          {isPending && <span className="status-badge badge-pending">Programada</span>}
          {isCancelled && <span className="status-badge badge-cancelled">Cancelada</span>}
          {isCompleted && <span className="status-badge badge-completed">Completada</span>}
          
          {isConfirmed && <span className="status-badge badge-confirmed">Confirmada</span>}
          
          {isPending && (
            <>
              <button className="action-button btn-confirm" onClick={() => onConfirm(appointment.id)}>
                Confirmar
              </button>
              <button className="action-button btn-cancel" onClick={() => onCancel(appointment.id)}>
                Cancelar
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminAppointmentCard;