import React, { useMemo } from 'react';
import { FaChartBar } from 'react-icons/fa';
import StatItem from './StatItem';
import '../styles/AdminStatistics.css';

// Datos de equipos (podrían venir de mock.js también)
const mockEquipment = [
    { id: 'e1', name: 'Servidor Dev', line: 'TICs', available: true },
    { id: 'e2', name: 'Impresora 3D', line: 'Ingeniería y diseño', available: false },
    { id: 'e3', name: 'Osciloscopio', line: 'Electrónica', available: true },
    { id: 'e4', name: 'Analizador Lógico', line: 'Electrónica', available: true },
    { id: 'e5', name: 'Microscopio', line: 'Biotecnología', available: true },
];

const AdminStatistics = () => {
  // Calculamos las estadísticas para cada línea usando useMemo para optimizar
  const lineStats = [] /*useMemo(() => {
    return projectLines.map(line => {
      const talents = mockUsers.filter(u => u.role === 'Talento').length; // Asumimos talentos totales, no por línea
      const experts = mockUsers.filter(u => u.role === 'Experto' && u.line === line).length;
      const appointments = mockAppointments.filter(a => a.line === line).length;
      const equipment = mockEquipment.filter(e => e.line === line);
      const availableEquipment = equipment.filter(e => e.available).length;

      return {
        name: line,
        key: line.toLowerCase().replace(/ y /g, '-').replace(/ /g, '-'), // ej: 'ingenieria-y-diseño'
        stats: [
          { label: 'Talentos', value: talents, color: 'blue' },
          { label: 'Expertos', value: experts, color: 'green' },
          { label: 'Citas', value: appointments, color: 'purple' },
          { label: 'Equipos', value: equipment.length, color: 'orange' },
          { label: 'Disponibles', value: availableEquipment, color: 'red' }
        ]
      };
    });
  }, []);*/

  return (
    <div className="admin-statistics-container card-style">
      <header className="management-header">
        <h4><FaChartBar /> Estadísticas por Línea de Proyecto</h4>
      </header>

      <div className="statistics-content">
        {lineStats.map(line => (
          <section key={line.key} className={`line-section-card bg-gradient-${line.key}`}>
            <header className="line-header">
              <h5 className="line-title">{line.name}</h5>
              <span className="line-key-badge">{line.key}</span>
            </header>
            <div className="stats-grid-inner">
              {line.stats.map(stat => (
                <StatItem key={stat.label} label={stat.label} value={stat.value} color={stat.color} />
              ))}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
};

export default AdminStatistics;