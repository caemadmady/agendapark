import React, { useEffect, useState } from "react";
import { FaCalendarAlt } from "react-icons/fa";
import AdminAppointmentCard from "./AdminAppointmentCard";
import "../styles/AppointmentManagement.css";
import { getAdminAppointments, updateAppointmentStatus } from "../services/admin.api.jsx";

const AppointmentManagement = () => {
  const [appointments, setAppointments] = useState([]);

 /*  useEffect(() => {
    const fetchAppointments = async () => {
      try {
        const data = await getAdminAppointments();
        setAppointments(data || []);
      } catch (err) {
        console.error("Error al cargar las citas:", err);
      }
    };
    fetchAppointments();
  }, []); */

  const handleConfirm = async (appointmentId) => {
    try {
      await updateAppointmentStatus(appointmentId, "Confirmada");
      setAppointments((prev) =>
        prev.map((apt) =>
          apt.id === appointmentId ? { ...apt, status: "Confirmada" } : apt
        )
      );
    } catch (err) {
      console.error("Error al confirmar cita:", err);
    }
  };

  const handleCancel = async (appointmentId) => {
    try {
      await updateAppointmentStatus(appointmentId, "Cancelada");
      setAppointments((prev) =>
        prev.map((apt) =>
          apt.id === appointmentId ? { ...apt, status: "Cancelada" } : apt
        )
      );
    } catch (err) {
      console.error("Error al cancelar cita:", err);
    }
  };

  return (
    <div className="appointment-management-container">
      <header className="management-header card-style">
        <h4><FaCalendarAlt /> Todas las Citas</h4>
      </header>

      <div className="appointment-list">
        {appointments?.length ? (
          appointments.map((apt) => (
            <AdminAppointmentCard
              key={apt.id}
              appointment={apt}
              onConfirm={handleConfirm}
              onCancel={handleCancel}
            />
          ))
        ) : (
          <p>No hay citas registradas.</p>
        )}
      </div>
    </div>
  );
};

export default AppointmentManagement;