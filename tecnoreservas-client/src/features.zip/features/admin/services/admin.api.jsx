import api from "../../../services/api.js";
import { apiFetch } from "../../../lib/api.js";

// Axios directo
export async function getUsers(query = "") {
  const { data } = await api.get(`/users${query ? `?q=${encodeURIComponent(query)}` : ""}`);
  return data;
}
export async function deleteUser(id) {
  const { data } = await api.delete(`/users/${id}`);
  return data;
}

// O usando apiFetch (funciona igual, por debajo es Axios)
export async function getProjectLines() {
  return apiFetch("/lines");
}

export async function createUser(userData) {
  return apiFetch("/users", {
    method: "POST",
    body: userData,
  });
}

export async function updateUser(id, userData) {
  return apiFetch(`/users/${id}`, {
    method: "PUT",
    body: userData,
  });
}

export async function getAdminAppointments() {
  return apiFetch("/appointments/admin");
}

export async function updateAppointmentStatus(appointmentId, status) {
  return apiFetch(`/appointments/${appointmentId}/status`, {
    method: "PUT",
    body: { status },
  });
}