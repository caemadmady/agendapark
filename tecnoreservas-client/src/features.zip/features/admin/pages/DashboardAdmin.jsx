import React from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { FaUsers, FaCalendarAlt, FaChartBar, FaCheckCircle, FaTimesCircle } from 'react-icons/fa';

// Importamos los estilos desde la carpeta centralizada
import '../../../features/admin/styles/DashboardAdmin.css';

// Componente para las tarjetas de estadísticas (diseño específico para el admin)
const AdminStatCard = ({ title, value, subtitle, icon, color }) => (
  <div className={`admin-stat-card card-style card-border-${color}`}>
    <div className="card-info">
      <p className="card-title">{title}</p>
      <p className="card-value">{value}</p>
      <p className="card-subtitle">{subtitle}</p>
    </div>
    <div className={`card-icon-wrapper icon-bg-${color}`}>{icon}</div>
  </div>
);

const DashboardAdmin = () => {
  return (
    <div className="dashboard-container">
      {/* Tarjetas de Estadísticas */}
      <section className="stats-grid">
        <AdminStatCard title="Total Usuarios" value="12" subtitle="6 talentos - 4 expertos" icon={<FaUsers />} color="purple" />
        <AdminStatCard title="Total Citas" value="6" subtitle="4 confirmadas" icon={<FaCalendarAlt />} color="blue" />
        <AdminStatCard title="Completadas" value="0" subtitle="Citas finalizadas con éxito" icon={<FaCheckCircle />} color="green" />
        <AdminStatCard title="Canceladas" value="2" subtitle="Citas no realizadas" icon={<FaTimesCircle />} color="red" />
      </section>

      {/* Pestañas de Navegación */}
      <section className="tabs-section-admin">
        <NavLink to="/admin/users" className="tab-button-admin">
          <FaUsers /> Usuarios
        </NavLink>
        <NavLink to="/admin/appointments" className="tab-button-admin">
          <FaCalendarAlt /> Citas
        </NavLink>
        <NavLink to="/admin/statistics" className="tab-button-admin">
          <FaChartBar /> Estadísticas
        </NavLink>
      </section>
      
      {/* Contenido dinámico (UserManagement, etc.) se renderiza aquí */}
      <main className="admin-content-area">
        <Outlet />
      </main>
    </div>
  );
};

export default DashboardAdmin;