import { apiFetch } from "../../../lib/api";

export async function getAllTalents() {
  const data = await apiFetch("/talents/all");
  return Array.isArray(data) ? data : (data.content ?? []);
}