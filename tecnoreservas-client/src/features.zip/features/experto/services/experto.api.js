// src/features/experto/services/experto.api.js
import api from "../../../services/api.js"; // la instancia de Axios que ya tiene token

// Traer info de una línea por su id
export async function fetchLinea(lineaId) {
  const response = await api.get(`/service-lines/${lineaId}`);
  return response.data; // objeto de la línea
}

// Traer todas las líneas (opcional)
export async function fetchLineas() {
  const response = await api.get("/service-lines");
  return response.data; // array de líneas
}

export async function listExpertsAll() {
  const response = await api.get("/experts");
  return response.data;
}
