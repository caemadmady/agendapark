// reservas.service.js
import { apiFetch } from "../../../lib/api";

// Reservas por línea (id numérico)
export async function getReservationsByLine(idLine) {
  const data = await apiFetch(`/reservations/serviceline/${idLine}`);
  return Array.isArray(data) ? data : (data.content ?? []);
}

// Cambiar estado: confirmed | canceled | fulfilled | missed
export async function updateReservationStatus(id, status) {
  return apiFetch(`/reservations/${status}/${id}`, { method: "PATCH" });
}

export async function createReservationByExpert(payload) {
  return apiFetch("/experts/create-reservations", {
    method: "POST",
    body: payload,
  });
}
