import { apiFetch } from "../../../lib/api";

// Equipos por línea: serviceLineId = "BIO" | "ING" | "ELE" | "TIC"
export async function getResourcesByLine(serviceLineId, page = 0, size = 10) {
  const data = await apiFetch(`/resources?page=${page}&size=${size}&serviceLineId=${encodeURIComponent(serviceLineId)}`);
  return Array.isArray(data) ? data : (data.content ?? []);
}