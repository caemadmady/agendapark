import React from "react";
import "../styles/CitasPendientes.css";

import lupacitapend from "../../../assets/lupa.png";

export default function CitasPendientes({
  reservations = [],
  onQuickAction,
  q,
  setQ,
  //loading
}) {
  const filtered = reservations.filter(r => {
    const term = q.toLowerCase();
    return (
      (r.project?.name || "").toLowerCase().includes(term) ||
      (r.talent?.name || "").toLowerCase().includes(term)
    );
  });

  return (
    <section className="xp-pending">

      <div className="xp-pending-head">
        <h2>Citas Pendientes</h2>

        <div className="search">
          <input
            type="text"
            img src={lupacitapend} alt="Icono_luapa" className="xp-lupa-img"
            placeholder="Buscar"
            value={q}
            onChange={e => setQ(e.target.value)}
          />
        </div>
      </div>

      <div className="table">
        <table>
          <thead>
            <tr>
              <th>Fecha</th>
              <th>Hora</th>
              <th>Proyecto</th>
              <th>Talento</th>
              <th>Acciones</th>
            </tr>
          </thead>

          <tbody>
            {filtered.map(r => (
              <tr key={r.id}>
                <td>{r.date}</td>
                <td>{r.hour}</td>
                <td>{r.project?.name}</td>
                <td>{r.talent?.name} {r.talent?.lastname}</td>
                <td>
                  <button onClick={() => onQuickAction(r.id, "confirmed")}>Confirmar</button>
                  <button onClick={() => onQuickAction(r.id, "canceled")}>Cancelar</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

    </section>
  );
}
