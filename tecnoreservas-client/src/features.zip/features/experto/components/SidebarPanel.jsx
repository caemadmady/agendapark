import React from "react";
import "../styles/SidebarPanel.css";

export default function SidebarPanel({ equipos, talentos, notificaciones }) {
  return (
    <div className="xp-side-panel">

      {/* EQUIPOS */}
      <div className="xp-card">
        <h3 className="xp-card-title">Equipos de Línea</h3>
        <div className="xp-scroll">
          {equipos?.length > 0 ? (
            equipos.map((eq) => (
              <div key={eq.id} className="xp-item">
                {eq.nombre}
              </div>
            ))
          ) : (
            <p className="xp-empty">No hay equipos</p>
          )}
        </div>
      </div>

      {/* TALENTOS */}
      <div className="xp-card">
        <h3 className="xp-card-title">Talentos Recientes</h3>
        <div className="xp-scroll">
          {talentos?.length > 0 ? (
            talentos.map((tal) => (
              <div key={tal.id} className="xp-item">
                {tal.nombre}
              </div>
            ))
          ) : (
            <p className="xp-empty">No hay talentos</p>
          )}
        </div>
      </div>

      {/* NOTIFICACIONES */}
      <div className="xp-card">
        <h3 className="xp-card-title">Notificaciones</h3>
        <div className="xp-scroll">
          {notificaciones?.length > 0 ? (
            notificaciones.map((n) => (
              <div key={n.id} className="xp-item">
                {n.mensaje}
              </div>
            ))
          ) : (
            <p className="xp-empty">Sin notificaciones</p>
          )}
        </div>
      </div>

    </div>
  );
}
