import React, { useEffect, useMemo, useRef, useState } from "react";
import "../styles/CitasCalendario.css";

import { useAuth } from "../../../auth/AuthContext";
import { getReservationsByLine } from "../services/reservas.service";

import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";
import esLocale from "@fullcalendar/core/locales/es";

export default function CitasCalendario() {
  const { me } = useAuth();
  const calendarRef = useRef(null);

  const [calView, setCalView] = useState("dayGridMonth");
  const [reservations, setReservations] = useState([]);

  // Cargar reservas por línea del experto
  useEffect(() => {
    if (!me?.linea) return;

    async function load() {
      try {
        const data = await getReservationsByLine(me.linea);
        setReservations(data);
      } catch (err) {
        console.error("Error cargando reservas:", err);
      }
    }

    load();
  }, [me]);

  // Convertir reservas del backend a eventos FullCalendar
  const events = useMemo(() => {
    return reservations.map((r) => ({
      id: String(r.id),
      title: `${r.talent?.name ?? ""} ${r.talent?.lastname ?? ""}`.trim(),
      start: r.dateTimeStart,   // Formato correcto ISO del backend
      end: r.endDateTime,
      extendedProps: {
        status: r.reservationStatus,
        project: r.projectName ?? r.project?.name ?? "",
      },
    }));
  }, [reservations]);

  // Cambiar vista manualmente
  const handleViewChange = (viewName) => {
    setCalView(viewName);
    if (calendarRef.current) {
      calendarRef.current.getApi().changeView(viewName);
    }
  };

  return (
    <div className="xp-cal-card">
      {/* Botones vista */}
      <div className="xp-cal-header">
        <button
          className={`xp-tab ${calView === "dayGridMonth" ? "on" : ""}`}
          onClick={() => handleViewChange("dayGridMonth")}
        >
          Mes
        </button>
        <button
          className={`xp-tab ${calView === "timeGridWeek" ? "on" : ""}`}
          onClick={() => handleViewChange("timeGridWeek")}
        >
          Semana
        </button>
        <button
          className={`xp-tab ${calView === "timeGridDay" ? "on" : ""}`}
          onClick={() => handleViewChange("timeGridDay")}
        >
          Día
        </button>
      </div>

      <div className="xp-cal-shell">
        <FullCalendar
          ref={calendarRef}
          plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
          initialView={calView}
          locale={esLocale}
          events={events}
          height="auto"
        />
      </div>
    </div>
  );
}
