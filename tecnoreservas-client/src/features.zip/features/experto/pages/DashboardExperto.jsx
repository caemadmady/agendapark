import React, { useEffect, useState } from "react";
import { useAuth } from "../../../auth/AuthContext";
import { fetchLinea } from "../services/experto.api.js";

// Componentes
import CitasCalendario from "../components/CitasCalendario";
import SidebarPanel from "../components/SidebarPanel";
import CitasPendientes from "../components/CitasPendientes";

import tics from "../../../assets/TICs.png";
import Calendaroexp from "../../../assets/calendario.png";

export default function DashboardExperto() {
  const { me } = useAuth();
  const [lineaData, setLinea] = useState(null);

  const lineaId = me?.linea || "TIC";

useEffect(() => {
  console.log("Usuario actual:", me);
  if (me?.linea) {
    fetchLinea(me.linea)
      .then(setLinea)
      .catch(err => console.error("Error al cargar la línea:", err));
  }
}, [me]);


  if (!lineaData) return <p>Cargando línea...</p>;

  return (
    <div className={`xp-page root-${lineaId}`}>
      <section className="xp-line-strip">
        <div className="xp-line-left">
          <img src={tics} alt={`Icono ${lineaData.service_line_name}`} className="xp-line-img" />
          <h2 className="xp-line-name">{lineaData.service_line_name}</h2>
        </div>
      </section>

      <section className="xp-section">
        <div className="xp-section-head">
          <div className="xp-section-title">
            <img src={Calendaroexp} alt="cal" className="calendar-icon" />
            <h3>Gestión de Citas</h3>
          </div>
        </div>

        <div className="xp-grid">
          <CitasCalendario />
          <SidebarPanel />
        </div>
      </section>

      <CitasPendientes />
    </div>
  );
}
