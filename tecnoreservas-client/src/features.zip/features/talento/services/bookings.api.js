// src/features/talento/services/bookings.api.js
import { apiFetch } from "../../../lib/api";

export async function getMyUpcomingReservations() {
  // si tu backend devuelve pageable, ajusto más abajo en la página
  return apiFetch('/reservations/user');
}

export async function createReservation(dto) {
  // dto: { dateTimeStart, endDateTime, expert, talent, notes?, resources? }
  return apiFetch('/reservations/create', { method: 'POST', body: dto });
}