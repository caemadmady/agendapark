import { apiFetch } from "../../../lib/api";

export async function listResourcesAll() {
  // algunos backends exponen /resources o /resources/
  const r = await apiFetch('/resources/');
  // puede venir {content: [...] } o directamente []
  return Array.isArray(r) ? r : (Array.isArray(r?.content) ? r.content : []);
}