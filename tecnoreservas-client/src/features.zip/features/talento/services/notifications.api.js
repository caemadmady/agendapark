import axios from "axios";

// Ejemplo de endpoint (ajusta la URL a tu backend real)
const API_URL = "/api/notifications";

export async function getMyNotificationsCount() {
  try {
    const res = await axios.get(`${API_URL}/count`);
    // Suponiendo que el backend devuelve { count: 5 }
    return res.data.count;
  } catch (e) {
    console.error("Error cargando notificaciones:", e);
    return 0;
  }
}
