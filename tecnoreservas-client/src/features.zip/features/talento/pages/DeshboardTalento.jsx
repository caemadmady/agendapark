import React, { useEffect, useMemo, useState } from "react";
import { Calendar, CheckCircle, Bell } from "lucide-react";
import "../styles/talento.css";

// Componentes
import AgendaCitas from "./AgendaCitas";
import MisCitas from "./MisCitas";

// Assets
import Diamante from "../../../assets/diamante.png";

// APIs
import { listExpertsAll } from "../../experto/services/experto.api.js";
import { getMyUpcomingReservations, createReservation } from "../services/bookings.api";
import { combineDateTime, addMinutes, toIsoLocal } from "../../../lib/datetime";
import { getMyNotificationsCount } from "../services/notifications.api";

// Líneas de proyecto disponibles
const LINEAS = [
    { id: "tics", nombre: "TICs" },
    { id: "biotec", nombre: "Biotecnología" },
    { id: "ingdis", nombre: "Ingeniería y Diseño" },
    { id: "elect", nombre: "Electrónica" },
];

export default function DashboardTalento() {
    const [showForm, setShowForm] = useState(false);

    // Formulario de nueva cita
    const [lineaId, setLineaId] = useState("");
    const [experto, setExperto] = useState("");
    const [fecha, setFecha] = useState("");
    const [hora, setHora] = useState("");
    const [duracion, setDuracion] = useState("60");
    const [notas, setNotas] = useState("");

    // Datos desde la API
    const [expertsAll, setExpertsAll] = useState([]);
    const [upcoming, setUpcoming] = useState([]);
    const [loadingUpcoming, setLoadingUpcoming] = useState(false);
    const [saving, setSaving] = useState(false);

    // KPIs
    const [completed, setCompleted] = useState(0);
    const [notifications, setNotifications] = useState(0);

    // Cargar expertos al montar el componente
    useEffect(() => {
        (async () => {
            try {
                const ex = await listExpertsAll();
                setExpertsAll(Array.isArray(ex) ? ex : []);
            } catch {
                setExpertsAll([]);
            }
        })();
    }, []);

    // Cargar citas programadas y calcular KPIs
    async function loadUpcoming() {
        setLoadingUpcoming(true);
        try {
            const data = await getMyUpcomingReservations();
            const list = Array.isArray(data) ? data : (Array.isArray(data?.content) ? data.content : []);
            setUpcoming(list);

            // Calcular citas completadas
            const completadas = list.filter((c) => c.status === "COMPLETED").length;
            setCompleted(completadas);
        } finally {
            setLoadingUpcoming(false);
        }
    }

    // Cargar notificaciones
    async function loadNotifications() {
        try {
            const count = await getMyNotificationsCount();
            setNotifications(count || 0);
        } catch {
            setNotifications(0);
        }
    }

    useEffect(() => {
        loadUpcoming();
        loadNotifications();
    }, []);

    // Filtrar expertos por línea seleccionada
    const expertos = useMemo(() => {
        if (!lineaId) return expertsAll;
        return (expertsAll || []).filter((e) => {
            const tag = (e?.line?.projectLine || e?.line?.id || e?.projectLine || '').toString().toLowerCase();
            return tag === lineaId.toLowerCase();
        });
    }, [expertsAll, lineaId]);

    function resetForm() {
        setLineaId("");
        setExperto("");
        setFecha("");
        setHora("");
        setDuracion("60");
        setNotas("");
    }

    function validar() {
        if (!lineaId) return "Selecciona una línea de proyecto.";
        if (!experto) return "Selecciona un experto.";
        if (!fecha) return "Selecciona una fecha.";
        if (!hora) return "Selecciona una hora.";

        const fechaSel = new Date(fecha);
        const hoy = new Date();
        hoy.setHours(0, 0, 0, 0);
        if (fechaSel < hoy) return "La fecha debe ser igual o posterior a hoy.";

        return "";
    }

    async function agendar() {
        const error = validar();
        if (error) {
            alert(error);
            return;
        }

        const start = combineDateTime(fecha, hora);
        const end = addMinutes(start, duracion);

        const dto = {
            dateTimeStart: toIsoLocal(start),
            endDateTime: toIsoLocal(end),
            expert: Number(experto),
            talent: null,
            notes: notas || ""
        };

        setSaving(true);
        try {
            await createReservation(dto);
            setShowForm(false);
            resetForm();
            await loadUpcoming();
            alert("Cita creada exitosamente.");
        } catch (e) {
            alert(e.message || "Error al crear la cita");
        } finally {
            setSaving(false);
        }
    }

    return (
        <div className="dashboard-container">
            {/* --- TARJETAS DE ESTADÍSTICAS (KPIs) --- */}
            <section className="stats-section">
                <div className="stat-card purple">
                    <Calendar size={55} />
                    <div>
                        <h3>{upcoming.length}</h3>
                        <p>Citas Programadas</p>
                    </div>
                </div>
                <div className="stat-card green">
                    <CheckCircle size={55} />
                    <div>
                        <h3>{completed}</h3>
                        <p>Citas Completadas</p>
                    </div>
                </div>
                <div className="stat-card orange">
                    <Bell size={55} />
                    <div>
                        <h3>{notifications}</h3>
                        <p>Notificaciones Nuevas</p>
                    </div>
                </div>
            </section>

            {/* --- SECCIÓN PRINCIPAL --- */}
            <section className="calendar-wrapper">
                <div className="calendar-section">
                    <h2>Mis Citas</h2>
                    <AgendaCitas
                        citas={upcoming}
                        loading={loadingUpcoming}
                    />
                </div>

                <div className="summary-section">
                    <h2>Resumen de Citas</h2>
                    <button
                        className="new-appointment"
                        onClick={() => setShowForm(true)}
                    >
                        + Nueva Cita
                    </button>
                </div>
            </section>

            {/* --- MODAL DE NUEVA CITA --- */}
            {showForm && (
                <MisCitas
                    onClose={() => {
                        setShowForm(false);
                        resetForm();
                    }}
                    lineas={LINEAS}
                    lineaId={lineaId}
                    setLineaId={setLineaId}
                    expertos={expertos}
                    experto={experto}
                    setExperto={setExperto}
                    fecha={fecha}
                    setFecha={setFecha}
                    hora={hora}
                    setHora={setHora}
                    duracion={duracion}
                    setDuracion={setDuracion}
                    notas={notas}
                    setNotas={setNotas}
                    onSubmit={agendar}
                    saving={saving}
                />
            )}
        </div>
    );
}