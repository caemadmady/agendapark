import React from "react";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";
import esLocale from "@fullcalendar/core/locales/es";

import "@fullcalendar/daygrid";
import "@fullcalendar/timegrid";

export default function AgendaCitas() {
  return (
    <div className="agenda-container">
      <FullCalendar
        plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
        initialView="dayGridMonth"
        locale={esLocale}
        headerToolbar={{
          left: "prev,next today",
          center: "title",
          right: "dayGridMonth,timeGridWeek,timeGridDay",
        }}
        buttonText={{
          today: "Hoy",
          month: "Mes",
          week: "Semana",
          day: "Día",
        }}
        events={[
          { title: "Cita con asesor", date: "2025-11-03" },
          { title: "Reunión técnica", date: "2025-11-07" },
        ]}
        height="auto"
        contentHeight="auto"
      />
    </div>
  );
}
