import React, { useState, useEffect, useRef } from "react";
import { Calendar } from "lucide-react";
import "../styles/talento.css";

export default function MisCitas({ onClose }) {
  const [formData, setFormData] = useState({
    linea: "",
    fecha: "",
    hora: "",
    duracion: "1 hora",
    notas: "",
  });

  const modalRef = useRef(null);

  // 👇 Detectar clic fuera del modal
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (modalRef.current && !modalRef.current.contains(e.target)) {
        onClose();
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [onClose]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Cita agendada:", formData);
    onClose();
  };

  return (
    <div className="modal-overlay">
      <div ref={modalRef} className="modal-content animate-modal">
        {/* --- ENCABEZADO --- */}
        <div className="modal-header">
          <h2>
            <Calendar size={24} color="#7c3aed" />
            Agendar Nueva Cita
          </h2>
          <button className="close-btn" onClick={onClose}>
            ✕
          </button>
        </div>

        <p className="modal-description">
          Completa los campos para agendar una cita con un experto.
        </p>

        {/* --- FORMULARIO --- */}
        <form onSubmit={handleSubmit}>
          <label>Línea de Proyecto *</label>
          <select
            name="linea"
            value={formData.linea}
            onChange={handleChange}
            required
          >
            <option value="">Selecciona una línea...</option>
            <option>Biotecnología</option>
            <option>Electrónica</option>
            <option>Ingeniería y Diseño</option>
            <option>TICs</option>
          </select>

          <div className="form-row">
            <div>
              <label>Fecha *</label>
              <input
                type="date"
                name="fecha"
                value={formData.fecha}
                onChange={handleChange}
                required
              />
              <small>📅 Disponible: Lunes a Viernes</small>
            </div>
            <div>
              <label>Hora *</label>
              <select
                name="hora"
                value={formData.hora}
                onChange={handleChange}
                required
              >
                <option value="">Selecciona...</option>
                <option>08:00 AM</option>
                <option>09:00 AM</option>
                <option>10:00 AM</option>
                <option>11:00 AM</option>
                <option>02:00 PM</option>
                <option>03:00 PM</option>
                <option>04:00 PM</option>
              </select>
            </div>
          </div>

          <label>Duración</label>
          <select
            name="duracion"
            value={formData.duracion}
            onChange={handleChange}
          >
            <option>30 minutos</option>
            <option>1 hora</option>
            <option>2 horas</option>
          </select>

          <label>Notas Adicionales</label>
          <textarea
            name="notas"
            value={formData.notas}
            onChange={handleChange}
            placeholder="Describe el propósito de la cita..."
          />

          <div className="form-buttons">
            <button type="button" onClick={onClose} className="cancel-btn">
              Cancelar
            </button>
            <button type="submit" className="submit-btn">
              Agendar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
